function attachEvents() {
    console.log("TODO...");

    const location = document.getElementById('location');
    const submitBtn = document.getElementById('submit');
    const forecast = document.getElementById('forecast');
    const current = document.querySelector('#current');
    const upcoming = document.querySelector('#upcoming');

    const url = 'http://localhost:3030/jsonstore/forecaster/locations';

    submitBtn.addEventListener('click', () => {

        forecast.style.display = 'block';
        fetch(url).then(response => {
            return response.json();
        }).then(result => {
            console.log(result)
            const locObj = result.find(l => l.name === location.value);
            const urlToday = 'http://localhost:3030/jsonstore/forecaster/today/' + locObj.code;
            fetch(urlToday).then(res => res.json())
                .then(data =>{
                    //today
                    console.log('today',data)
                    const div = createEl('div','','forecasts');
                    let condition = data.forecast.condition;
                    let icon = getWeatherIcon(condition);
                    div.appendChild(createEl('span', icon,'condition symbol'));
                    const span = createEl('span','','condition');
                    span.appendChild(createEl('span',data.name,'forecast-data'))
                    span.appendChild(createEl('span',`${data.forecast.low}°/${data.forecast.high}°`,'forecast-data'))
                    span.appendChild(createEl('span',condition,'forecast-data'))
                    div.appendChild(span);
                    current.appendChild(div)
                }).catch(error =>{
                console.log(error)
            })
            const urlUpcoming = 'http://localhost:3030/jsonstore/forecaster/upcoming/' + locObj.code;
            fetch(urlUpcoming).then(response => response.json())
                .then(data => {
                    console.log('upcomming',data)
                    const div = createEl('div','','forecast-info');
                    data.forecast.forEach(el => {
                        let condition = el.condition;
                        let icon = getWeatherIcon(condition);
                        const span = createEl('span','','upcoming');
                        span.appendChild(createEl('span',icon,'symbol'));
                        span.appendChild(createEl('span',`${el.low}°/${el.high}°`,'forecast-data'));
                        span.appendChild(createEl('span',condition,'forecast-data'));
                        div.appendChild(span);
                    })
                    upcoming.appendChild(div);

                }).catch(err => {
                console.log(err)
            })

        }).catch(err => {

        })
    })

    function createEl(tag,content,className){
        const element = document.createElement(tag);
        element.textContent = content;
        if (className){
            element.className = className;
        }
        return element;
    }
    function getWeatherIcon(condition) {
        const types = {
            'Sunny': '☀',
            'Partly sunny': '⛅',
            'Overcast': '☁',
            'Rain': '☂',
            'Degrees': '°'
        };
        return types[condition];
    }

    //SECOND SOLUTION
    // const idField = document.getElementById('location');
    // const submitBtn = document.getElementById('submit');
    // const forecast = document.getElementById('forecast');
    // const current = document.getElementById('current');
    // const upcoming = document.getElementById('upcoming');
    // const label = document.querySelector('.label');
    //
    // submitBtn.addEventListener('click', getData);
    //
    // async function getData() {
    //     try {
    //         const locationUrl = `http://localhost:3030/jsonstore/forecaster/today/${idField.value}`;
    //         const response = await fetch(locationUrl);
    //         const data = await response.json();
    //
    //         const upcomingUrl = `http://localhost:3030/jsonstore/forecaster/upcoming/${idField.value}`;
    //         const res = await fetch(upcomingUrl);
    //         const dataUpcoming = await res.json();
    //
    //         forecast.style.display = 'block';
    //
    //         createCurrent(data);
    //         createUpcoming(dataUpcoming);
    //
    //     } catch (error) {
    //         label.textContent = 'Error';
    //         forecast.style.display = '';
    //         upcoming.style.display = 'none';
    //     }
    // }
    //
    // function createCurrent(data) {
    //     const divForecasts = createComponent('div', '', 'forecasts');
    //     const conditionSymbol = createComponent('span', getWeatherIcon(data.forecast.condition), 'condition symbol')
    //     const spanCondition = createComponent('span', '', 'condition');
    //     const forecastDataOne = createComponent('span', data.name, 'forecast-data');
    //     const forecastDataTwo = createComponent('span', `${data.forecast.low}°/${data.forecast.high}°`, 'forecast-data');
    //     const forecastDataThree = createComponent('span', data.forecast.condition, 'forecast-data');
    //
    //     spanCondition.appendChild(forecastDataOne);
    //     spanCondition.appendChild(forecastDataTwo);
    //     spanCondition.appendChild(forecastDataThree);
    //
    //     divForecasts.appendChild(conditionSymbol);
    //     divForecasts.appendChild(spanCondition);
    //
    //     current.appendChild(divForecasts);
    // }
    //
    // function createUpcoming(dataUpcoming) {
    //     const forecastDiv = createComponent('div', '', 'forecasts-info');
    //
    //     dataUpcoming.forecast.forEach(el => {
    //         const upcomingSpan = createComponent('span', '', 'upcoming');
    //         const symbolSpan = createComponent('span', getWeatherIcon(el.condition), 'symbol');
    //         const forecastSpan = createComponent('span', `${el.low}°/${el.high}°`, 'forecast-data',);
    //         const wordSpan = createComponent('span', el.condition, 'forecast-data');
    //
    //         upcomingSpan.appendChild(symbolSpan);
    //         upcomingSpan.appendChild(forecastSpan);
    //         upcomingSpan.appendChild(wordSpan);
    //         forecastDiv.appendChild(upcomingSpan);
    //     });
    //
    //     upcoming.appendChild(forecastDiv);
    // }
    //
    // function createComponent(type, content, className) {
    //     const element = document.createElement(type);
    //     element.innerHTML = content;
    //     element.className = className;
    //     return element;
    // }
    //
    // function getWeatherIcon(condition) {
    //     const types = {
    //         'Sunny': '&#x2600',
    //         'Partly sunny': '&#x26C5',
    //         'Overcast': '&#x2601',
    //         'Rain': '&#x2614',
    //         'Degrees': '&#176'
    //     };
    //     return types[condition];
    // }

}

attachEvents();